import express from 'express';
import nunjucks from 'nunjucks';
import path from 'path';
import fs from 'fs';

// path 모듈의 resolve() 함수를 이용해 현재 실행되는 파일의 절대 경로를 구함
const __dirname = path.resolve();
console.log("__dirname : ", __dirname);

// join() 함수는 인수를 순서대로 조합해 경로 문자열을 반환하는 함수
// file path : memo-app/data/file_data.json
const filePath = path.join(__dirname, 'data', 'file_data.json');

// Express 서버 인스턴스 생성 - app은 express의 기능을 담고 있는 객체
const app = express();

// req.body를 사용해서 요청 본문의 데이터를 받기 위한 미들웨어
// Express v4.16.0에서 body-paraser가 빌트인 되어 별도의 모듈이 필요없음
// JSON 미들웨어를 사용하지 않으면 req.body는 undefined가 반환됨
app.use(express.json());

// POST 요청 시 Content-type이 application/x-www-form-urlencoded인 
// 경우 파싱해 주는 설정으로 JSON 미들웨어와 같이 사용해야 함
app.use(express.urlencoded({ extended: true }));

// CSS, JavaScript, html 파일과 같은 정적 파일을 제공하려면 Express에서
// 기본 제공하는 미들웨어인 static() 함수의 인수로 정적 파일을 제공할
// 디렉터리를 지정하면 된다. 아래와 같이 public 디렉터리가 지정되면
// public/index.css 파일은 http://localhost:3000/index.css로 지정하면 됨
app.use(express.static(path.join(__dirname, 'public')))

// 템플릿 엔진을 사용하는 설정으로 템플릿 엔진의 파일 확장자를 html로 설정
// 파일 확장자는 꼭 html이 아니어도 되며 임의로 설정할 수 있음
app.set('view engine', 'html');  // main.html => main

// 뷰 페이지의 경로를 지정해 Nunjucks 환경 설정
nunjucks.configure('views', {
  watch: true,  // html 파일이 수정되면 수정된 내용을 반영하여 다시 렌더링
  express: app
});

// 메모 목록 요청을 처리 라우터
app.get("/", async (req, res) => {
  // data/file_data.json 파일에서 데이터 읽기
  const fileData = fs.readFileSync(filePath);

  // JSON 문자열을 자바스크립트 객체로 변환
  const list = JSON.parse(fileData);

  // 응답 객체의 render() 함수로 뷰의 이름과 뷰에 출력할 데이터를 전달하면
  // 위에서 템플릿 엔진 파일 형식을 html로 설정하고 Nunjucks 환경 설정에서
  // 'views' 폴더를 지정했기 때문에 /views/main.html 찾아서 렌더링 해 준다.
  // 최신 글을 맨 위에 출력하기 위해 배열의 순서를 뒤집어 지정함 
  res.render("main", {list: list.reverse()});
});

// 메모 상세보기 요청을 처리하는 라우터
app.get("/detail/:no", async (req, res) => {
  
  /* Path Variable : 경로 구분자(/)로 데이터를 구분해서 받는 방식
    * 요청 url : detail/10/20
    * 라우팅 설정 : "/detail/:no/:test"
    * Path Variable 방식은 request 객체의 params 속성으로 값을 받음
    **/
  let no = req.params.no;
  let test = req.params.test;
  console.log("no : ", no, " - test : ", test);

  // data/file_data.json 파일의 데이터 읽기 
  const fileData = fs.readFileSync(filePath);

  // JSON 문자열을 자바스크립트 객체로 변환
  const dataList = JSON.parse(fileData);
  
  // 파일에서 읽어온 배열에서 no와 일치하는 데이터 찾기
  let data = dataList.find((elem, index) => {          
    if(elem.no == no) {
      return true;
    }
  });
  console.log(data);
  res.render("detail", {data: data});
});

// 메모 작성 폼 요청을 처리하는 라우터
app.get("/write", (req, res) => {
  // 화면에 출력한 데이터가 없으면 뷰 페이지만 지정할 수 있음
  res.render("write");
});

// 메모 작성 폼에서 들어오는 메모 작성 요청을 처리하는 라우터
app.post("/write", async (req, res) => {
  const title = req.body.title;
  const contents = req.body.contents;
  const writer = req.body.writer;
  const date = req.body.date;

  // 기존 파일 데이터를 읽어와 맨 마지막에 새로 작성되는 데이터 저장
  // data/data_list.json 파일의 데이터 읽어오기
  const fileData = fs.readFileSync(filePath);
  const dataList = JSON.parse(fileData);
  
  let no = dataList.length - 1;
  if(no < 0) {
    // 파일에서 읽어온 데이터가 없으면 새로 입력하는 데이터의 no = 1
    no = 1;
    
  } else {
    // 파일에서 읽어온 데이터가 있으면 마지막 데이터의 no + 1
    no = dataList[dataList.length -1].no + 1;
  }
  // 파일에서 읽어온 배열 객체에 데이터 저장
  dataList.push({ no: no, title: title, contents: contents, writer: writer, date: date });
  
  // 파일에 데이터 저장
  fs.writeFileSync(filePath, JSON.stringify(dataList));

  // 글쓰기 후에 리다이렉트
  res.redirect("/");
});

app.listen(3000, () => {
  console.log(`Memo App 서버 시작 - http://localhost:3000/`);
});